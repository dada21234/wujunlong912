# 提示词记录

## 2026-10-22 提示词记录

- **时间**：2026-10-22（Asia/Shanghai）
- **模型**：GLM-5.3-Flash
- **提示词内容**：
  1. 设定规则：从现在开始，所有CSS类名，id名、js变量都以 `wjl_` 开始，所有的提示词都在执行之前写入文件 `wjl_prompt.md`，以附加的方式写入，不覆盖之前的内容，写入的内容包括时间、使用的模型、提示词内容。
- **说明**：记录文件由 `wy_prompt.md` 更正为 `wjl_prompt.md`；命名前缀维持 `wjl_`。

## 2026-10-22 提示词记录（第2条）

- **时间**：2026-10-22（Asia/Shanghai）
- **模型**：GLM-5.3-Flash
- **提示词内容**：
  1. 设置规则：新建的html文件加入超链接到首页index.htm
- **说明**：项目当前首页文件实际为 `index.html`，新建页面将以 `<a href="index.html">返回首页</a>` 形式链接到首页。

## 2026-10-22 提示词记录（第3条）

- **时间**：2026-10-22（Asia/Shanghai）
- **模型**：GLM-5.3-Flash
- **提示词内容**：
  1. 做两个html网页iconfont-1.html,inconfont-2.html，分别显示font awesome图标和lucide图标，前者使用字体图标的方式，后者使用svg的方式，相关的cdn文件下载到本目录下的cdn目录。
- **说明**：用户笔误 `inconfont-2.html`，按上下文理解为 `iconfont-2.html`。iconfont-1.html 用 Font Awesome 字体（webfont）方式，iconfont-2.html 用 Lucide SVG 方式；CDN 资源（CSS/字体文件/JS）下载到 `e:\gaojiwangye\cdn\` 目录，页面引用本地文件。

## 2026-10-22 提示词记录（第4条）

- **时间**：2026-10-22（Asia/Shanghai）
- **模型**：GLM-5.3-Flash
- **提示词内容**：
  1. 请根据skills下面的frontend-design里面的skill去优化iconfont-1.html和iconfont-2.html两个页面的设计等个，使其更有艺术美感，更优雅。
- **说明**：按 frontend-design skill 的设计规范重新设计两个图标展示页面的视觉风格，保持功能与本地资源引用不变。

## 2026-10-26 14:56:05
- 模型：GLM-5.3-Flash
- 提示词：这是相关数据的js以及等级一的任务与要求（附 data.js、等级一任务截图、starter-level1.html 模板，要求补全 5 个函数实现学生成绩分析面板）


## 2026-10-28 22:15:21
- 模型：GLM-5.3-Flash
- 提示词：将完成后的代码发给我


## 2026-10-28 22:22:48
- 模型：GLM-5.3-Flash
- 提示词：把我弄成starter-level1.html的代码文件


## 2026-10-29 14:22:37
- 模型：GLM-5.3-Flash
- 提示词：创建技能skill：提交到github，将本项目提交commit并push到`https://github.com/dada21234/wujunlong912.git`，使用已生成的公钥。


## 2026-10-29 15:02:08
- 模型：GLM-5.3-Flash
- 提示词：save灰色（GitHub Pages 设置页的保存按钮是灰的，附截图）


## 2026-11-02 13:28:03
- 模型：GLM-5.3-Flash
- 提示词：修改规则AGENTS.md在新建一个html文件时，要加入注释，尤其是js部分代码函数的主要功能实现。注释内容包括：吴君龙，建立时间，使用模型，功能名称及简介


## 2026-11-02 13:40:23
- 模型：GLM-5.3-Flash
- 提示词：新建html文件显示tab选项卡（国内/国际/省内/最热新闻，国内默认选中），js单独放js文件夹外部引用且选项卡可复用，含事件监听、清除所有选中状态再设置当前元素选中状态


## 2026-11-02 14:29:27
- 模型：GLM-5.3-Flash
- 提示词：E:\烧\课堂测试\5 一比一还原里面的内容（4张图），js要使用外部引用


## 2026-11-02 14:48:14
- 模型：GLM-5.3-Flash
- 提示词：上传到GitHub仓库（使用 commit-to-github skill 推送到 dada21234/wujunlong912）


## 2026-11-02 15:00:01
- 模型：GLM-5.3-Flash
- 提示词：我将index.html文件覆盖了，需要重新上传吗


## 2026-11-02 15:07:58
- 模型：GLM-5.3-Flash
- 提示词：为什么变成这样了（热播榜页面只有选项卡、榜单空白，附截图）


## 2026-11-09 13:23:07
- 模型：DeepSeek-V4.1-Flash
- 提示词：帮我完成相应效果（附 swiper-task.html 课堂任务模板，要求补全底部 script 中 4 个 Swiper 轮播的初始化代码与效果切换逻辑）


## 2026-11-09 13:41:20
- 模型：DeepSeek-V4.1-Flash
- 提示词：任务一的实现（附「任务一·提示词工程师：让 AI 听懂需求」截图，要求针对 `#wySw4` 的 loop / 3.2 秒自动播放且手动操作后不停 / 圆点可点 / 初始 effect 为 cube，完成两轮提示词迭代记录、AI 回答与逐项验证）


## 2026-11-09 14:20:36
- 模型：DeepSeek-V4.1-Flash
- 提示词：好的，生成验证页（新建一个能直接截图取证的任务一验证页，贴入第 2 轮 cube 配置并给出逐项自查项）


## 2026-11-09 15:02:48
- 模型：DeepSeek-V4.1-Flash
- 提示词：关于任务二的实现，实现完了之后告诉我 prev/next 的 transform 各控制什么？（附「任务二·creative 仿写」截图：为演示四新增第 7 个按钮 creative 电影墙，上一张缩小左移带角度、下一张放大右移进场，并解释 prev/next 的 transform）


## 2026-11-09 15:36:10
- 模型：DeepSeek-V4.1-Flash
- 提示词：关于任务三的实现，帮我选一个没讲过的 swiper 能力，四个任选其一的我选择 zoom 双击缩放（附「任务三·综合创作 + 技术答辩」截图：新增第六件展品爱达·魔都号、图片 AI 生成 16:9、slide 结构完整，并实现 zoom 双击缩放 + 关键对话记录 + 答辩四连问）


## 2026-11-11 09:15:22
- 模型：DeepSeek-V4.1-Flash
- 提示词：把答辩四联问去掉


## 2026-11-11 09:22:40
- 模型：DeepSeek-V4.1-Flash
- 提示词：在 index.html 里面将 wjl_task3_zoom.html、wjl_task1_verify.html、wjl_rank_list.html、wjl_prompt.md 链接起来

